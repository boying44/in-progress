# drops columns and turn categorical features to numerical
def process(df, exculde_cols = [], to_numeric_cols = []):
    if exclude_cols:
        df = df.drop(exclude_cols, axis=1) # axis=1 to drop from columns, axis=0 drops entries
    df = pd.get_dummies(to_numeric_cols, drop_first=True)
    return df