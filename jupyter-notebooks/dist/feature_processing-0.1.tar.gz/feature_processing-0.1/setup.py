from distutils.core import setup

setup(name='feature_processing',
version='0.1',
description='tools for feature processing',
packages=['feature_processing'], # promise that distutils will find feature_processing/__init__.py
url='https://github.com/boying44/in-progress',
author='Boying Tang',
author_email="boying.tang.44@gmail.com"
)